#!/usr/bin/env bash
# ============================================================================
#  HALCYON - macOS plug-in repair / diagnostic
#  Double-click this file (or run: bash fix_mac_plugins.command).
#  Use it when Halcyon was copied from a download instead of built with
#  build.sh, or when a host (Logic, Camelot, Ableton...) refuses to load it.
#  It removes the download quarantine, re-signs the plug-ins locally, forces
#  macOS to rescan Audio Units and runs Apple's validator.
# ============================================================================
cd "$(dirname "$0")"
VST3="$HOME/Library/Audio/Plug-Ins/VST3/Halcyon.vst3"
AU="$HOME/Library/Audio/Plug-Ins/Components/Halcyon.component"
APP="/Applications/Halcyon.app"

echo "== Halcyon plug-in repair =="
# copy plug-ins sitting next to this script (downloaded package) into place
for src in Halcyon.vst3 VST3/Halcyon.vst3; do [ -d "$src" ] && { rm -rf "$VST3"; mkdir -p "$(dirname "$VST3")"; cp -R "$src" "$VST3"; echo "installed $VST3"; }; done
for src in Halcyon.component AU/Halcyon.component; do [ -d "$src" ] && { rm -rf "$AU"; mkdir -p "$(dirname "$AU")"; cp -R "$src" "$AU"; echo "installed $AU"; }; done

# copies left in the system-wide folder override / confuse the user ones
for p in "/Library/Audio/Plug-Ins/VST3/Halcyon.vst3" "/Library/Audio/Plug-Ins/Components/Halcyon.component"; do
    [ -e "$p" ] && echo "WARNING: an older copy exists in $p - delete it (sudo rm -rf \"$p\") to avoid conflicts."
done

for p in "$VST3" "$AU" "$APP"; do
    [ -e "$p" ] || { echo "not found: $p"; continue; }
    xattr -cr "$p" 2>/dev/null
    codesign --force --deep -s - "$p" >/dev/null 2>&1 && echo "signed:   $p" || echo "could not sign: $p"
done

echo
echo "== Architecture (must include $(uname -m)) =="
[ -e "$AU" ] && lipo -info "$AU/Contents/MacOS/Halcyon" 2>/dev/null
[ -e "$VST3" ] && lipo -info "$VST3/Contents/MacOS/Halcyon" 2>/dev/null

killall -9 AudioComponentRegistrar >/dev/null 2>&1

echo
echo "== Apple AU validation =="
LOG="$HOME/Desktop/halcyon_auval.txt"
if auval -v aumu Hlc1 Hlcn > "$LOG" 2>&1; then
    echo "AU VALIDATION SUCCEEDED"
else
    echo "AU validation FAILED. Last lines (full report: $LOG):"
    tail -30 "$LOG"
fi
echo
echo "Logic Pro / MainStage / GarageBand only use the Audio Unit (not VST3):"
echo "  1. Logic > Settings > Plug-in Manager: select Halcyon, click 'Reset & Rescan Selection', tick 'Use'."
echo "  2. Create a SOFTWARE INSTRUMENT track, click the Instrument slot > AU Instruments > Halcyon Audio > Halcyon."
echo "     (Halcyon is an instrument: it never appears in Audio FX slots.)"
echo "Other hosts: rescan plug-ins (VST3 folder: ~/Library/Audio/Plug-Ins/VST3)."
