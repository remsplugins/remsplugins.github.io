#!/bin/bash
# Installs Lucky Beats from this folder, lifts the macOS quarantine and forces a plug-in rescan.
cd "$(dirname "$0")"
VST3_DIR="$HOME/Library/Audio/Plug-Ins/VST3"; AU_DIR="$HOME/Library/Audio/Plug-Ins/Components"
mkdir -p "$VST3_DIR" "$AU_DIR"
[ -d VST3/LuckyBeats.vst3 ] && rm -rf "$VST3_DIR/LuckyBeats.vst3" && cp -R VST3/LuckyBeats.vst3 "$VST3_DIR/"
[ -d AU/LuckyBeats.component ] && rm -rf "$AU_DIR/LuckyBeats.component" && cp -R AU/LuckyBeats.component "$AU_DIR/"
for b in "$VST3_DIR/LuckyBeats.vst3" "$AU_DIR/LuckyBeats.component" "Standalone/LuckyBeats.app"; do
  [ -d "$b" ] || continue
  xattr -dr com.apple.quarantine "$b" 2>/dev/null
  codesign --force --deep -s - "$b" 2>/dev/null
done
killall -9 AudioComponentRegistrar 2>/dev/null
echo "Lucky Beats is installed. Restart your DAW and rescan plug-ins."
